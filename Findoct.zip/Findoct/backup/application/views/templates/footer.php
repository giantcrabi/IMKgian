	<footer class="container-fluid text-center">
		<p>Footer Text</p>
	</footer>
	<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-2.1.3.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
</body>
</html>