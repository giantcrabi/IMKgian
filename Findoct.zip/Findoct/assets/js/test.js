$(document).ready(function() {
    alert("I am an alert box2!");   
});