<?php
	echo "<script>";
	echo 'alert("Delete Berhasil");';
	echo "window.location.href = '../'";
	echo "</script>";
    exit;