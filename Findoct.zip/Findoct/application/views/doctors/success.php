<?php
	echo "<script>";
	echo 'alert("Submit Berhasil");';
	echo "window.location.href = './$user'";
	echo "</script>";
    exit;