<?php
	echo "<script>";
	echo 'alert("Berhasil");';
	echo "window.location.href = '../../$doctors_item[Username]'";
	echo "</script>";
    exit;