<div class="container-fluid">    
  <div class="row content">
    <h1 style="vertical-align:middle; text-align:center; font-family: bebas neue;">Pencarian Dokter Berdasarkan Penyakit</h1>
    <div class="col-md-12" style="display:table-cell; vertical-align:middle; text-align:center">
      <br>
      <select>
        <option value="volvo">--Pilih--</option>
        <option value="saab">Influenza</option>
        <option value="mercedes">Kulit</option>
        <option value="audi">THT</option>
      </select>
      <button>GO</button>
    </div>
    
  </div>
</div>