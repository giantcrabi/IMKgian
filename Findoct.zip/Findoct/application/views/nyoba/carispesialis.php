<div class="container-fluid">    
  <div class="row content">
    <h1 style="vertical-align:middle; text-align:center; font-family: bebas neue;">Pencarian Dokter Berdasarkan Spesialis</h1>
    <div class="col-md-12" style="display:table-cell; vertical-align:middle; text-align:center">
      <br>
      <select>
        <option value="volvo">--Pilih--</option>
        <option value="saab">Anak</option>
        <option value="audi">Dalam</option>
        <option value="mercedes">Kulit dan Kelamin</option>
        <option value="audi">THT</option>
      </select>
      <a href="<?php echo base_url("/maps/Sp.THT-KL"); ?>"><button>GO</button></a>
    </div>
    
  </div>
</div>