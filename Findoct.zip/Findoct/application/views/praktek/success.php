<?php
	echo "<script>";
	echo 'alert("Submit Berhasil");';
	echo "window.location.href = './$idtempat'";
	echo "</script>";
    exit;