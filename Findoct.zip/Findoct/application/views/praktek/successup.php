<?php
	echo "<script>";
	echo 'alert("Update Berhasil");';
	echo "window.location.href = '../$praktek_item[IDTPraktek]'";
	echo "</script>";
    exit;